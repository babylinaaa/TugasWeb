<h1>Daftar Profile</h1>

<a href="{{ route('profiles.create') }}">Tambah Profile</a>

<table>
    <thead>
        <tr>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Email</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($profiles as $profile)
            <tr>
                <td>{{ $profile->nama }}</td>
                <td>{{ $profile->alamat }}</td>
                <td>{{ $profile->email }}</td>
                <td>
                    <a href="{{ route('profiles.edit', $profile->id) }}">Edit</a>
                    <form action="{{ route('profiles.destroy', $profile->id) }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit">Hapus
